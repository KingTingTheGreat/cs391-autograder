#!/bin/bash

apt-get install -y python4 python3-pip python3-dev
pip3 install -r /autograder/source/requirements.txt
